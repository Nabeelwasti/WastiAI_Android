package com.example.data.agent.runtime

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Stage8MultiAgentFoundationTest {

    private lateinit var context: Context
    private lateinit var realityRegistry: CapabilityRealityRegistry
    private lateinit var fabric: UnifiedExecutionFabric
    private lateinit var coordinator: AgentTaskCoordinator

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        realityRegistry = CapabilityRealityRegistry()
        fabric = UnifiedExecutionFabric(
            realityRegistry = realityRegistry,
            eventBus = AgentEventBus(),
            auditEngine = RealityAuditEngine(realityRegistry, WastiCredentialBroker()),
            appContext = context
        )
        coordinator = AgentTaskCoordinator(fabric)
    }

    @Test
    fun testSubAgentCatalogDefaults() {
        val agents = WastiSubAgentCatalog.defaultSubAgents
        assertTrue(agents.isNotEmpty())

        val codingAgent = coordinator.selectAgentForRole(AgentRole.CODING)
        assertNotNull(codingAgent)
        assertEquals("Coding Architect", codingAgent!!.name)

        val testingAgent = coordinator.selectAgentForRole(AgentRole.TESTING)
        assertNotNull(testingAgent)
        assertEquals("Testing & Verification Specialist", testingAgent!!.name)

        val securityAgent = coordinator.selectAgentForRole(AgentRole.SECURITY)
        assertNotNull(securityAgent)
        assertEquals(0.0f, securityAgent!!.temperature, 0.01f)
    }

    @Test
    fun testTaskCreationAndAgentSelection() {
        val task = coordinator.createTask(
            title = "Analyze Compiler Error",
            description = "Diagnose syntax error in workspace script",
            requiredCapabilities = listOf("debug_project")
        )

        assertNotNull(task)
        assertEquals(AgentRole.DEBUGGING, task.assignedRole)
        assertEquals("wasti_debugging_agent", task.assignedAgentId)
        assertEquals(AgentTaskState.SCHEDULED, task.state)
    }

    @Test
    fun testTaskDependencyResolutionAndScheduling() {
        val task1 = coordinator.createTask(
            title = "Build Project",
            description = "Build the workspace project",
            assignedRole = AgentRole.CODING,
            priority = AgentTaskPriority.HIGH
        )

        val task2 = coordinator.createTask(
            title = "Run Unit Tests",
            description = "Run tests on built artifact",
            assignedRole = AgentRole.TESTING,
            dependencies = listOf(task1.taskId),
            priority = AgentTaskPriority.MEDIUM
        )

        assertEquals(AgentTaskState.SCHEDULED, coordinator.getTask(task1.taskId)?.state)
        assertEquals(AgentTaskState.PENDING, coordinator.getTask(task2.taskId)?.state)

        // Ready tasks should only contain task1
        val readyBefore = coordinator.getReadyTasks()
        assertTrue(readyBefore.any { it.taskId == task1.taskId })
        assertFalse(readyBefore.any { it.taskId == task2.taskId })

        // Record completion for task 1
        coordinator.recordResult(
            AgentResult(
                taskId = task1.taskId,
                agentId = "wasti_coding_agent",
                role = AgentRole.CODING,
                state = AgentTaskState.COMPLETED,
                output = "Build verified successfully",
                executionTimeMs = 120L
            )
        )

        // Now task2 should be scheduled and ready
        assertEquals(AgentTaskState.SCHEDULED, coordinator.getTask(task2.taskId)?.state)
        val readyAfter = coordinator.getReadyTasks()
        assertTrue(readyAfter.any { it.taskId == task2.taskId })
    }

    @Test
    fun testDelegationAndSharedContext() {
        val parentTask = coordinator.createTask(
            title = "Implement Feature",
            description = "Full feature lifecycle",
            assignedRole = AgentRole.EXECUTIVE
        )

        val subTask = coordinator.createTask(
            title = "Security Audit",
            description = "Verify boundary constraints",
            assignedRole = AgentRole.CODING
        )

        val delegation = coordinator.delegateTask(
            parentTaskId = parentTask.taskId,
            subTask = subTask,
            sourceAgentId = "wasti_executive_agent",
            targetRole = AgentRole.SECURITY,
            reason = "Privileged operation requires security review",
            sharedContextKeys = listOf("policy_level")
        )

        assertEquals("wasti_executive_agent", delegation.sourceAgentId)
        assertEquals(AgentRole.SECURITY, delegation.targetRole)
        assertEquals(AgentRole.SECURITY, coordinator.getTask(subTask.taskId)?.assignedRole)

        // Shared context verification
        coordinator.sharedContext.set("policy_level", "STRICT")
        assertEquals("STRICT", coordinator.sharedContext.get("policy_level"))
        assertTrue(coordinator.sharedContext.getLogs().isNotEmpty())
    }

    @Test
    fun testTaskCancellationAndDependencyBlocking() {
        val taskA = coordinator.createTask(
            title = "Task A",
            description = "Root task"
        )
        val taskB = coordinator.createTask(
            title = "Task B",
            description = "Dependent on A",
            dependencies = listOf(taskA.taskId)
        )

        coordinator.cancelTask(taskA.taskId, "User aborted operation")

        assertEquals(AgentTaskState.CANCELLED, coordinator.getTask(taskA.taskId)?.state)
        assertEquals(AgentTaskState.BLOCKED, coordinator.getTask(taskB.taskId)?.state)
    }
}
