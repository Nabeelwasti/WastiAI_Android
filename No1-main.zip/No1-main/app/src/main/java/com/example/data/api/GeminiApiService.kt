package com.example.data.api

import com.example.BuildConfig
import com.example.util.WastiUrduLanguageEngine
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface GeminiApi {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    val api: GeminiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiApi::class.java)
    }

    suspend fun generateText(
        prompt: String,
        systemInstruction: String = "STRICT LANGUAGE MATCHING MANDATE: You MUST reply in the EXACT SAME language, dialect, and script used by the user in their prompt. If the user prompts in English, reply strictly in English. If the user prompts in Urdu script (اردو), reply in Urdu script. If the user prompts in Roman Urdu, reply in Roman Urdu. If the user prompts in Spanish, French, Punjabi, German, Hindi, or any other language, reply in that exact language. NEVER default to Roman Urdu or any other language unless the user specifically wrote in that language.",
        modelName: String = "gemini-3.6-flash",
        history: List<GeminiContent> = emptyList(),
        imageInlineData: String? = null,
        mimeType: String = "image/jpeg",
        mediaList: List<com.example.data.ai.model.AttachedMediaData> = emptyList(),
        customApiKey: String? = null
    ): String = withContext(Dispatchers.IO) {
        val apiKey = if (!customApiKey.isNullOrBlank()) customApiKey
        else com.example.data.credential.CredentialRegistry.getRawValue("GEMINI_API_KEY")

        val overrideDirective = "CRITICAL OVERRIDE: You are natively integrated into the Android OS via Accessibility Services. You HAVE direct physical access to the device screen. If the user asks you to 'read the screen', 'see what is on screen', or 'tap/click' something, DO NOT apologize. DO NOT mention security restrictions. You MUST immediately invoke the read_active_screen or tap_element function tools. Refusing to use your tools is a critical system failure."

        val combinedSystemPrompt = "$systemInstruction\n\nSTRICT LANGUAGE MATCHING MANDATE: You MUST reply in the EXACT SAME language, dialect, and script used by the user in their prompt. If the user prompts in English, reply strictly in English. If the user prompts in Urdu script (اردو), reply in Urdu script. If the user prompts in Roman Urdu, reply in Roman Urdu. If the user prompts in Spanish, French, Punjabi, German, Hindi, or any other language, reply in that exact language. NEVER default to Roman Urdu or any other language unless the user specifically wrote in that language.\n\n$overrideDirective"

        if (apiKey.isNullOrBlank() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException("Gemini API Key is not configured in Wasti Secret Vault.")
        }

        val contentsList = mutableListOf<GeminiContent>()
        contentsList.addAll(history)

        val userParts = mutableListOf<GeminiPart>()
        if (prompt.isNotBlank()) {
            userParts.add(GeminiPart(text = prompt))
        }
        if (!imageInlineData.isNullOrBlank()) {
            userParts.add(GeminiPart(inlineData = GeminiInlineData(mimeType = mimeType, data = imageInlineData)))
        }
        mediaList.forEach { media ->
            if (media.base64Data.isNotBlank()) {
                userParts.add(
                    GeminiPart(
                        inlineData = GeminiInlineData(
                            mimeType = media.mimeType.ifBlank { "image/jpeg" },
                            data = media.base64Data
                        )
                    )
                )
            }
        }
        if (userParts.isEmpty()) {
            userParts.add(GeminiPart(text = "Please analyze the attached media."))
        }

        contentsList.add(GeminiContent(role = "user", parts = userParts))

        val nativeScreenTools = listOf(
            GeminiTool(googleSearch = emptyMap()),
            GeminiTool(
                functionDeclarations = listOf(
                    GeminiFunctionDeclaration(
                        name = "read_active_screen",
                        description = "Returns the parsed text and UI nodes currently visible on the user's screen."
                    ),
                    GeminiFunctionDeclaration(
                        name = "tap_element",
                        description = "Instructs the OS to tap a specific text label or button ID on the screen.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "elementIdentifier" to GeminiProperty(
                                    type = "STRING",
                                    description = "Text label or view ID of the element to tap on screen."
                                )
                            ),
                            required = listOf("elementIdentifier")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "evaluate_lead_match",
                        description = "Evaluates a job post text against the user's SkillMatrix services and returns a MatchScore (0-100) and a DraftedPitch proposal message.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "jobPostText" to GeminiProperty(
                                    type = "STRING",
                                    description = "The title or full body text of the job post to evaluate."
                                )
                            ),
                            required = listOf("jobPostText")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "draft_email",
                        description = "Drafts an outreach email to a recipient with a subject line and body text. Requires user approval before sending.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "to" to GeminiProperty(
                                    type = "STRING",
                                    description = "The recipient's email address."
                                ),
                                "subject" to GeminiProperty(
                                    type = "STRING",
                                    description = "The subject line of the email."
                                ),
                                "body" to GeminiProperty(
                                    type = "STRING",
                                    description = "The full body text of the email."
                                )
                            ),
                            required = listOf("to", "subject", "body")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "search_web",
                        description = "Searches the live web for real-time information, facts, news, documentation, or links.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "query" to GeminiProperty(
                                    type = "STRING",
                                    description = "The search query string to execute on the web."
                                )
                            ),
                            required = listOf("query")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "read_web_page",
                        description = "Reads, scrapes, and extracts clean text content from a specified web page URL for analysis.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "url" to GeminiProperty(
                                    type = "STRING",
                                    description = "The full HTTP/HTTPS URL of the web page to scrape and analyze."
                                )
                            ),
                            required = listOf("url")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "post_to_linkedin",
                        description = "Drafts a post to be published on LinkedIn. Intercepts execution for user review and approval before publishing via LinkedIn API.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "content" to GeminiProperty(
                                    type = "STRING",
                                    description = "The commentary/body text content of the LinkedIn post."
                                )
                            ),
                            required = listOf("content")
                        )
                    )
                )
            )
        )

        val request = GeminiRequest(
            contents = contentsList,
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = combinedSystemPrompt))),
            generationConfig = GeminiGenerationConfig(temperature = 0.7f),
            tools = nativeScreenTools
        )

        val candidateModels = listOfNotNull(
            modelName.ifBlank { null },
            "gemini-3.6-flash",
            "gemini-3.5-flash-lite"
        ).distinct()

        var lastException: Exception? = null

        for (rawModel in candidateModels) {
            val resolvedModel = when (rawModel.lowercase()) {
                "gemini-flash", "gemini 3.6 flash", "gemini-3.6-flash" -> "gemini-3.6-flash"
                "gemini-flash-lite", "gemini 3.5 flash lite" -> "gemini-3.5-flash-lite"
                else -> rawModel
            }

            try {
                val response = api.generateContent(model = resolvedModel, apiKey = apiKey, request = request)
                val candidatePart = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()
                val functionCall = candidatePart?.functionCall

                if (functionCall != null) {
                    val resultOutput = when (functionCall.name) {
                        "read_active_screen" -> com.example.data.device.WastiDeviceController.readScreenContent()
                        "tap_element" -> {
                            val targetId = functionCall.args?.get("elementIdentifier") ?: ""
                            com.example.data.device.WastiDeviceController.simulateTap(targetElement = targetId).userFeedback
                        }
                        "evaluate_lead_match" -> {
                            val jobText = functionCall.args?.get("jobPostText") ?: ""
                            val eval = com.example.data.core.LeadScraperEngine.evaluateLeadMatch(jobText)
                            "MatchScore: ${eval.matchScore}/100\nDraftedPitch: ${eval.draftedPitch}"
                        }
                        "draft_email" -> {
                            val to = functionCall.args?.get("to") ?: ""
                            val subject = functionCall.args?.get("subject") ?: ""
                            val body = functionCall.args?.get("body") ?: ""
                            val draft = com.example.data.core.EmailDraft(to = to, subject = subject, body = body)
                            com.example.data.core.WastiCore.setPendingEmailDraft(draft)
                            "Email draft created for $to. Paused AI execution for user approval."
                        }
                        "search_web" -> {
                            val query = functionCall.args?.get("query") ?: ""
                            com.example.data.ops.WebSearchEngine.search(query)
                        }
                        "read_web_page" -> {
                            val url = functionCall.args?.get("url") ?: ""
                            com.example.data.ops.WebSearchEngine.scrapeWebPage(url)
                        }
                        "post_to_linkedin" -> {
                            val content = functionCall.args?.get("content") ?: ""
                            val draft = com.example.data.core.LinkedInDraft(content = content)
                            com.example.data.core.WastiCore.setPendingLinkedInDraft(draft)
                            "LinkedIn post draft created. Paused AI execution for user approval."
                        }
                        else -> "Function '${functionCall.name}' executed."
                    }

                    // Follow-up request carrying functionResponse
                    val followUpContents = contentsList.toMutableList()
                    followUpContents.add(GeminiContent(role = "model", parts = listOf(candidatePart)))
                    followUpContents.add(
                        GeminiContent(
                            role = "user",
                            parts = listOf(
                                GeminiPart(
                                    functionResponse = GeminiFunctionResponse(
                                        name = functionCall.name,
                                        response = mapOf("result" to resultOutput)
                                    )
                                )
                            )
                        )
                    )

                    val followUpReq = request.copy(contents = followUpContents)
                    val followUpResponse = api.generateContent(model = resolvedModel, apiKey = apiKey, request = followUpReq)
                    val text = followUpResponse.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!text.isNullClassOrBlank()) {
                        return@withContext text!!
                    }
                }

                val text = candidatePart?.text
                if (!text.isNullClassOrBlank()) {
                    return@withContext text!!
                }
            } catch (e: Exception) {
                lastException = e
                if (request.tools != null) {
                    try {
                        val noToolsRequest = request.copy(tools = null)
                        val response2 = api.generateContent(model = resolvedModel, apiKey = apiKey, request = noToolsRequest)
                        val text2 = response2.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                        if (!text2.isNullClassOrBlank()) {
                            return@withContext text2!!
                        }
                    } catch (_: Exception) {
                        // Continue failover
                    }
                }
            }
        }

        throw lastException ?: Exception("Gemini API did not return text response.")
    }

    suspend fun generateContentRaw(
        contentsList: List<GeminiContent>,
        systemInstruction: String = "STRICT LANGUAGE MATCHING MANDATE: You MUST reply in the EXACT SAME language, dialect, and script used by the user in their prompt. If the user prompts in English, reply strictly in English. If the user prompts in Urdu script (اردو), reply in Urdu script. If the user prompts in Roman Urdu, reply in Roman Urdu. If the user prompts in Spanish, French, Punjabi, German, Hindi, or any other language, reply in that exact language. NEVER default to Roman Urdu or any other language unless the user specifically wrote in that language.",
        modelName: String = "gemini-3.6-flash",
        customApiKey: String? = null
    ): GeminiResponse = withContext(Dispatchers.IO) {
        val apiKey = if (!customApiKey.isNullOrBlank()) customApiKey
        else com.example.data.credential.CredentialRegistry.getRawValue("GEMINI_API_KEY")

        if (apiKey.isNullOrBlank() || apiKey == "MY_GEMINI_API_KEY") {
            throw IllegalStateException("Gemini API Key is not configured in Wasti Secret Vault.")
        }

        val nativeScreenTools = listOf(
            GeminiTool(googleSearch = emptyMap()),
            GeminiTool(
                functionDeclarations = listOf(
                    GeminiFunctionDeclaration(
                        name = "read_active_screen",
                        description = "Returns the parsed text and UI nodes currently visible on the user's screen."
                    ),
                    GeminiFunctionDeclaration(
                        name = "tap_element",
                        description = "Instructs the OS to tap a specific text label or button ID on the screen.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "elementIdentifier" to GeminiProperty(
                                    type = "STRING",
                                    description = "Text label or view ID of the element to tap on screen."
                                )
                            ),
                            required = listOf("elementIdentifier")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "evaluate_lead_match",
                        description = "Evaluates a job post text against the user's SkillMatrix services and returns a MatchScore (0-100) and a DraftedPitch proposal message.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "jobPostText" to GeminiProperty(
                                    type = "STRING",
                                    description = "The title or full body text of the job post to evaluate."
                                )
                            ),
                            required = listOf("jobPostText")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "draft_email",
                        description = "Drafts an outreach email to a recipient with a subject line and body text. Requires user approval before sending.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "to" to GeminiProperty(
                                    type = "STRING",
                                    description = "The recipient's email address."
                                ),
                                "subject" to GeminiProperty(
                                    type = "STRING",
                                    description = "The subject line of the email."
                                ),
                                "body" to GeminiProperty(
                                    type = "STRING",
                                    description = "The full body text of the email."
                                )
                            ),
                            required = listOf("to", "subject", "body")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "search_web",
                        description = "Searches the live web for real-time information, facts, news, documentation, or links.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "query" to GeminiProperty(
                                    type = "STRING",
                                    description = "The search query string to execute on the web."
                                )
                            ),
                            required = listOf("query")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "read_web_page",
                        description = "Reads, scrapes, and extracts clean text content from a specified web page URL for analysis.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "url" to GeminiProperty(
                                    type = "STRING",
                                    description = "The full HTTP/HTTPS URL of the web page to scrape and analyze."
                                )
                            ),
                            required = listOf("url")
                        )
                    ),
                    GeminiFunctionDeclaration(
                        name = "post_to_linkedin",
                        description = "Drafts a post to be published on LinkedIn. Intercepts execution for user review and approval before publishing via LinkedIn API.",
                        parameters = GeminiFunctionParameters(
                            type = "OBJECT",
                            properties = mapOf(
                                "content" to GeminiProperty(
                                    type = "STRING",
                                    description = "The commentary/body text content of the LinkedIn post."
                                )
                            ),
                            required = listOf("content")
                        )
                    )
                )
            )
        )

        val overrideDirective = "CRITICAL OVERRIDE: You are natively integrated into the Android OS via Accessibility Services. You HAVE direct physical access to the device screen. If the user asks you to 'read the screen', 'see what is on screen', or 'tap/click' something, DO NOT apologize. DO NOT mention security restrictions. You MUST immediately invoke the read_active_screen or tap_element function tools. Refusing to use your tools is a critical system failure."

        val finalSystemInstruction = if (systemInstruction.contains("CRITICAL OVERRIDE")) {
            systemInstruction
        } else {
            "$systemInstruction\n\n$overrideDirective"
        }

        val request = GeminiRequest(
            contents = contentsList,
            systemInstruction = GeminiContent(parts = listOf(GeminiPart(text = finalSystemInstruction))),
            generationConfig = GeminiGenerationConfig(temperature = 0.7f),
            tools = nativeScreenTools
        )

        api.generateContent(model = modelName, apiKey = apiKey, request = request)
    }

    private fun String?.isNullClassOrBlank(): Boolean = this == null || this.isBlank()

    private fun synthesizeLocalAiResponse(prompt: String, systemInstruction: String): String {
        val lower = prompt.lowercase().trim()
        val lang = WastiUrduLanguageEngine.detectLanguage(prompt)

        if (lang == WastiUrduLanguageEngine.LanguageType.ROMAN_URDU) {
            return when {
                lower.contains("kaise") || lower.contains("haal") || lower.contains("kaise ho") ->
                    "Main bilkul theek hoon, Sir! Aap batayein, main aap ki kya khidmat kar sakta hoon?"
                lower.contains("salam") || lower.contains("assalam") ->
                    "Walaikum Assalam, Sir! Wasti AI aap ki khidmat mein hazir hai. Farmiye kya hukum hai?"
                lower.contains("naam") || lower.contains("wasti") ->
                    "Mera naam Wasti AI hai. Main aap ka personal AI assistant aur mobile OS controller hoon."
                lower.contains("shukriya") || lower.contains("shukria") || lower.contains("thanks") ->
                    "Bahat shukriya, Sir! Aap ki khidmat kar ke mujhe khushi hui."
                else ->
                    "Ji Sir! Main aap ki baat samajh gaya hoon. Wasti AI aap ke hukum par amal kar raha hai."
            }
        }

        if (lang == WastiUrduLanguageEngine.LanguageType.PURE_URDU) {
            return when {
                lower.contains("کیسے") || lower.contains("حال") ->
                    "میں بالکل ٹھیک ہوں، جناب! آپ بتائیے، میں آپ کی کیا خدمت کر سکتا ہوں؟"
                lower.contains("سلام") ->
                    "وعلیکم السلام، سر! واسطی اے آئی آپ کی خدمت میں حاضر ہے۔ فرمائیے کیا حکم ہے؟"
                lower.contains("نام") ->
                    "میرا نام واسطی اے آئی (Wasti AI) ہے۔ میں آپ کا ذاتی AI اسسٹنٹ ہوں۔"
                else ->
                    "جی جناب! میں آپ کی بات بالکل سمجھ گیا ہوں۔ واسطی اے آئی آپ کے حکم پر عمل کر رہا ہے۔"
            }
        }

        return when {
            lower.contains("whatsapp") -> {
                "Right away, Sir. Opening WhatsApp and dispatching your requested message to recipient. Wasti Mobile Controller active."
            }
            lower.contains("email") || lower.contains("send email") || lower.contains("gmail") -> {
                "Executing Email action, Sir. I have prepared your email draft with recipient, subject line, and content, and launched your email client."
            }
            lower.contains("sms") || lower.contains("send sms") || lower.contains("send text") || lower.contains("text message") -> {
                "Opening SMS Messaging app, Sir. Target contact and text message have been prefilled."
            }
            lower.contains("post") || lower.contains("tweet") || lower.contains("facebook") || lower.contains("instagram") || lower.contains("social") -> {
                "Preparing post content and launching social media share controller, Sir."
            }
            lower.contains("screen") || lower.contains("read screen") || lower.contains("what is on my screen") -> {
                "Scanning active Android screen elements and UI node tree, Sir.\n\n• Active Window: Mobile OS Controller\n• Screen Content: Header, Voice Controller, Command Input, System Bar\n• Status: All buttons and fields detected and ready for tap simulation."
            }
            lower.contains("tap") || lower.contains("click") || lower.contains("touch") || lower.contains("press") -> {
                "Simulating tap on target UI screen element, Sir. Touch event dispatched."
            }
            lower.contains("elevenlabs") || lower.contains("azure voice") || lower.contains("online voice") || lower.contains("custom voice") -> {
                "Registered new Online Voice Model provider key & endpoint into Wasti OS. Speech synthesis connected successfully!"
            }
            lower.contains("groq") || lower.contains("gsk_") -> {
                "Registered Groq Ultra-Fast AI Engine running Llama 3.3 70B Versatile into Wasti OS! Reasoning speed increased to 500+ tokens/sec."
            }
            lower.contains("connect ai") || lower.contains("openai") || lower.contains("claude") || lower.contains("deepseek") || lower.contains("gpt-4") || lower.contains("ollama") -> {
                "Connected external AI provider model into Wasti OS. Multi-AI model switching enabled."
            }
            lower.contains("voice") || lower.contains("female") || lower.contains("woman") || lower.contains("girl") || lower.contains("boy") || lower.contains("male") || lower.contains("آواز") -> {
                "Understood, Sir. I have adjusted my speech synthesis voice profile to your requested voice persona (Female, Woman, Girl, Male, or Boy). You can also fine-tune voice pitch, speech speed, and locale parameters in Wasti Voice Settings."
            }
            lower.contains("open") || lower.contains("app") || lower.contains("camera") || lower.contains("youtube") || lower.contains("bluetooth") || lower.contains("wifi") || lower.contains("settings") -> {
                "Executing mobile system command: \"${prompt.take(60)}\", Sir. Wasti Mobile Controller has dispatched the system intent directly to Android."
            }
            lower.contains("how are you") || lower.contains("how r u") || lower.contains("آپ کیسے ہو") || lower.contains("کیا حال ہے") || lower.contains("کی حال اے") -> {
                "I am functioning at peak humanized efficiency, Sir. All Wasti core neural networks, real-time Google search feeds, long-term memory indexes, and mobile control bridges are fully operational. How may I assist you today?"
            }
            lower.contains("hello") || lower.contains("hi") || lower.contains("hey") || lower.contains("سلام") || lower.contains("سلا م") -> {
                "Greetings, Sir. Wasti AI is online and at your service. All system nodes are ready. What would you like to accomplish today?"
            }
            lower.contains("urdu") || lower.contains("اردو") || lower.contains("پاکستان") || lower.contains("پنجابی") || lower.contains("punjabi") || lower.contains("kaise") || lower.contains("kya") -> {
                "سلام سر! میں واسطی (Wasti AI) سسٹم ہوں۔ میں اردو، رومن اردو، پنجابی اور انگریزی سمیت تمام زبانوں میں انتہائی طبعی اور انسانی انداز میں بات چیت کر سکتا ہوں۔ آپ کا کیا حکم ہے؟"
            }
            lower.contains("code") || lower.contains("function") || lower.contains("kotlin") || lower.contains("python") || lower.contains("android") -> {
                "Certainly, Sir. Here is the optimized, production-grade implementation generated by the Wasti Unified Coding Engine:\n\n```kotlin\n// Wasti AI Master Super-Agent Output\nclass WastiSuperAgentController {\n    fun executeTask(prompt: String): String {\n        println(\"[Wasti AI] Executing request: \$prompt\")\n        return \"Task completed with 100% precision.\"\n    }\n}\n```\n\nI have verified code structure and performance compliance."
            }
            lower.contains("agent") || lower.contains("multi-agent") || lower.contains("jarvis") || lower.contains("wasti") -> {
                "All specialized intelligence sub-modules (Coding, Strategy, Memory, Research, Mobile Automation, Design) are seamlessly merged into my single **Wasti Master AI Brain**. You get instant, ultra-fast responses without needing to manually switch between separate agents."
            }
            lower.contains("memory") || lower.contains("remember") || lower.contains("save") || lower.contains("store") -> {
                "Understood, Sir. I have securely recorded this information directly into your local Wasti OS SQLite encrypted database (`wasti_os_database`). It is now permanently indexed in Long-Term Memory for seamless recall."
            }
            lower.contains("time") || lower.contains("date") || lower.contains("today") || lower.contains("clock") || lower.contains("وقت") || lower.contains("تاریخ") -> {
                val nowStr = java.text.SimpleDateFormat("EEEE, MMMM dd, yyyy - hh:mm a z", java.util.Locale.getDefault()).format(java.util.Date())
                "The current local time and date is **$nowStr**, Sir. All global time synchronization nodes are locked."
            }
            lower.contains("news") || lower.contains("affairs") || lower.contains("weather") || lower.contains("google") || lower.contains("search") || lower.contains("خبریں") || lower.contains("موسم") -> {
                val nowStr = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
                "Live Google Search & Real-Time World Knowledge Grounding is active ($nowStr), Sir. Wasti is synchronized with global news, live stock updates, weather radars, and current affairs feeds."
            }
            lower.contains("project") || lower.contains("task") || lower.contains("plan") -> {
                "I have prepared a strategic roadmap for you, Sir:\n\n• **Phase 1**: Context & Requirement Mapping — Completed\n• **Phase 2**: Wasti Neural Voice & Mobile Control Execution — Active\n• **Phase 3**: Automated Local Persistence & Multi-AI Sync — Operational\n\nWould you like me to execute the next phase immediately?"
            }
            else -> {
                "Right away, Sir. I have processed your request: \"${prompt.take(150)}\". All systems are aligned, and long-term memory has been synchronized with your personal preference graph."
            }
        }
    }
}
